#!/bin/bash

export LD_LIBRARY_PATH=.:jre/bin:$LD_LIBRARY_PATH
java -agentlib:NativeDecrypt=dec_httpclient.xml -jar httpclient_enc.jar $1